"use client"

import { create } from "zustand"

export type Screen = 
  | "login" 
  | "create-order" 
  | "ai-result" 
  | "available-bids" 
  | "submit-bid" 
  | "orders-list"
  | "profile"

export interface Order {
  id: string
  carModel: string
  carYear: string
  detectedParts: string[]
  photo: string | null
  status: "active" | "completed" | "cancelled"
  selectedBid?: Bid
  bids: Bid[]
  createdAt: Date
}

export interface Bid {
  id: string
  supplierName: string
  supplierNameAr: string
  price: number
  condition: "new" | "used"
  warranty: string
  warrantyAr: string
}

interface AppState {
  // Navigation
  currentScreen: Screen
  
  // Auth
  phoneNumber: string
  otp: string
  isLoggedIn: boolean
  userType: "customer" | "supplier" | null
  
  // Current Order
  currentOrder: {
    carModel: string
    carYear: string
    photo: string | null
    detectedParts: string[]
  }
  
  // Orders - Start empty
  orders: Order[]
  currentOrderId: string | null
  
  // Submit Bid Form
  submitBidForm: {
    condition: "new" | "used" | ""
    warranty: string
    price: string
  }
  
  // Actions
  setScreen: (screen: Screen) => void
  setPhoneNumber: (phone: string) => void
  setOtp: (otp: string) => void
  login: (userType: "customer" | "supplier") => void
  logout: () => void
  setCarDetails: (model: string, year: string) => void
  setPhoto: (photo: string | null) => void
  setDetectedParts: (parts: string[]) => void
  submitOrder: () => string
  selectBid: (orderId: string, bidId: string) => void
  rejectBid: (orderId: string, bidId: string) => void
  resetCurrentOrder: () => void
  setCurrentOrderId: (id: string | null) => void
  updateSubmitBidForm: (form: Partial<AppState["submitBidForm"]>) => void
  resetSubmitBidForm: () => void
  submitSupplierBid: () => void
}

export const useAppStore = create<AppState>((set, get) => ({
  currentScreen: "login",
  phoneNumber: "",
  otp: "",
  isLoggedIn: false,
  userType: null,
  
  currentOrder: {
    carModel: "",
    carYear: "",
    photo: null,
    detectedParts: [],
  },
  
  // Start with empty orders
  orders: [],
  
  currentOrderId: null,
  
  submitBidForm: {
    condition: "",
    warranty: "",
    price: "",
  },
  
  setScreen: (screen) => set({ currentScreen: screen }),
  setPhoneNumber: (phone) => set({ phoneNumber: phone }),
  setOtp: (otp) => set({ otp }),
  
  login: (userType) => set({ isLoggedIn: true, userType, otp: "" }),
  
  logout: () => set({ 
    isLoggedIn: false, 
    userType: null, 
    phoneNumber: "", 
    otp: "",
    currentScreen: "login" 
  }),
  
  setCarDetails: (model, year) =>
    set((state) => ({
      currentOrder: { ...state.currentOrder, carModel: model, carYear: year },
    })),
  
  setPhoto: (photo) =>
    set((state) => ({
      currentOrder: { ...state.currentOrder, photo },
    })),
  
  setDetectedParts: (parts) =>
    set((state) => ({
      currentOrder: { ...state.currentOrder, detectedParts: parts },
    })),
  
  submitOrder: () => {
    const state = get()
    const newOrderId = `${Math.floor(Math.random() * 9000) + 1000}`
    const newOrder: Order = {
      id: newOrderId,
      carModel: state.currentOrder.carModel,
      carYear: state.currentOrder.carYear,
      detectedParts: state.currentOrder.detectedParts,
      photo: state.currentOrder.photo,
      status: "active",
      bids: [],
      createdAt: new Date(),
    }
    set((state) => ({
      orders: [newOrder, ...state.orders],
      currentOrderId: newOrderId,
      currentOrder: {
        carModel: "",
        carYear: "",
        photo: null,
        detectedParts: [],
      },
    }))
    return newOrderId
  },
  
  selectBid: (orderId, bidId) =>
    set((state) => ({
      orders: state.orders.map((order) =>
        order.id === orderId 
          ? { 
              ...order, 
              selectedBid: order.bids.find(b => b.id === bidId),
              status: "completed" as const
            } 
          : order
      ),
    })),
  
  rejectBid: (orderId, bidId) =>
    set((state) => ({
      orders: state.orders.map((order) =>
        order.id === orderId 
          ? { 
              ...order, 
              bids: order.bids.filter(b => b.id !== bidId)
            } 
          : order
      ),
    })),
  
  resetCurrentOrder: () =>
    set({
      currentOrder: {
        carModel: "",
        carYear: "",
        photo: null,
        detectedParts: [],
      },
    }),
    
  setCurrentOrderId: (id) => set({ currentOrderId: id }),
  
  updateSubmitBidForm: (form) =>
    set((state) => ({
      submitBidForm: { ...state.submitBidForm, ...form },
    })),
    
  resetSubmitBidForm: () =>
    set({
      submitBidForm: {
        condition: "",
        warranty: "",
        price: "",
      },
    }),
    
  submitSupplierBid: () => {
    const state = get()
    const { submitBidForm, currentOrderId } = state
    if (!currentOrderId || !submitBidForm.condition || !submitBidForm.price) return
    
    const newBid: Bid = {
      id: `${Date.now()}`,
      supplierName: "Your Company",
      supplierNameAr: "شركتك",
      price: parseInt(submitBidForm.price) || 0,
      condition: submitBidForm.condition as "new" | "used",
      warranty: submitBidForm.warranty || "No warranty",
      warrantyAr: submitBidForm.warranty || "بدون ضمان",
    }
    
    set((state) => ({
      orders: state.orders.map((order) =>
        order.id === currentOrderId 
          ? { ...order, bids: [...order.bids, newBid] }
          : order
      ),
      submitBidForm: { condition: "", warranty: "", price: "" },
    }))
  },
}))
