"use client"

import { createContext, useContext, useState, ReactNode } from "react"

type Language = "ar" | "en"

interface Translations {
  [key: string]: {
    ar: string
    en: string
  }
}

const translations: Translations = {
  // App name
  appName: { ar: "موترك", en: "Motark" },
  
  // Login screen
  phoneNumber: { ar: "رقم الجوال", en: "Phone Number" },
  otp: { ar: "رمز التحقق", en: "OTP" },
  resendCode: { ar: "إعادة إرسال الرمز", en: "Resend Code" },
  login: { ar: "تسجيل الدخول", en: "Login" },
  noAccount: { ar: "ليس لديك حساب؟", en: "Don't have an account?" },
  signUp: { ar: "إنشاء حساب", en: "Sign Up" },
  or: { ar: "أو", en: "OR" },
  loginByEmail: { ar: "الدخول بالبريد الإلكتروني", en: "Login by email" },
  registerAsWorkshop: { ar: "التسجيل كورشة أو مورد", en: "Register as workshop or supplier" },
  invalidOtp: { ar: "رمز التحقق غير صحيح", en: "Invalid OTP code" },
  sendOtp: { ar: "إرسال رمز التحقق", en: "Send OTP" },
  verifyOtp: { ar: "التحقق من الرمز", en: "Verify OTP" },
  otpSent: { ar: "تم إرسال رمز التحقق", en: "OTP sent" },
  enterOtp: { ar: "أدخل رمز التحقق المرسل", en: "Enter the OTP sent to your phone" },
  changeNumber: { ar: "تغيير الرقم", en: "Change number" },
  
  // Navigation Menu
  home: { ar: "الرئيسية", en: "Home" },
  newOrder: { ar: "طلب جديد", en: "New Order" },
  profile: { ar: "ملفي الشخصي", en: "My Profile" },
  notifications: { ar: "الإشعارات", en: "Notifications" },
  settings: { ar: "الإعدادات", en: "Settings" },
  help: { ar: "المساعدة", en: "Help & Support" },
  logout: { ar: "تسجيل الخروج", en: "Logout" },
  customer: { ar: "عميل", en: "Customer" },
  supplier: { ar: "مورد", en: "Supplier" },
  availableOrders: { ar: "الطلبات المتاحة", en: "Available Orders" },
  myBids: { ar: "عروضي", en: "My Bids" },
  
  // Create order screen
  createOrder: { ar: "إنشاء طلب", en: "Create Order" },
  aiAnalysis: { ar: "تحليل بالذكاء الاصطناعي", en: "AI Analysis" },
  carDetails: { ar: "تفاصيل السيارة", en: "Car Details" },
  model: { ar: "الموديل", en: "Model" },
  year: { ar: "السنة", en: "Year" },
  takePhoto: { ar: "التقاط / رفع صورة", en: "Take / Upload Photo" },
  withAI: { ar: "بالذكاء الاصطناعي", en: "with AI" },
  selectModel: { ar: "اختر الموديل", en: "Select Model" },
  selectYear: { ar: "اختر السنة", en: "Select Year" },
  
  // AI Result screen
  aiResult: { ar: "نتيجة الذكاء الاصطناعي", en: "AI Result" },
  submitOrder: { ar: "إرسال الطلب", en: "Submit Order" },
  photo: { ar: "الصورة", en: "Photo" },
  detected: { ar: "تم اكتشاف", en: "Detected" },
  editAddDetails: { ar: "تعديل / إضافة تفاصيل", en: "Edit / Add more details" },
  sendToSuppliers: { ar: "إرسال للموردين", en: "Send order to Suppliers" },
  frontBumper: { ar: "الصدام الأمامي", en: "Front Bumper" },
  rightHeadlight: { ar: "المصباح الأيمن", en: "Right Headlight" },
  
  // Available Bids screen
  availableBids: { ar: "العروض المتاحة", en: "Available Bids" },
  offersFor: { ar: "العروض لـ", en: "Offers for" },
  condition: { ar: "الحالة", en: "Condition" },
  new: { ar: "جديد", en: "New" },
  used: { ar: "مستعمل", en: "Used" },
  warranty: { ar: "الضمان", en: "Warranty" },
  months: { ar: "أشهر", en: "Months" },
  year1: { ar: "سنة", en: "Year" },
  sar: { ar: "ريال", en: "SAR" },
  noBidsYet: { ar: "لا توجد عروض بعد", en: "No bids yet" },
  waitingForSuppliers: { ar: "في انتظار عروض الموردين", en: "Waiting for supplier bids" },
  
  // Submit Bid screen
  submitBid: { ar: "تقديم عرض", en: "Submit Bid" },
  orderParts: { ar: "قطع الطلب", en: "Order Parts" },
  pricingFields: { ar: "حقول التسعير", en: "Pricing Fields" },
  price: { ar: "السعر", en: "Price" },
  send: { ar: "إرسال", en: "Send" },
  noOrdersAvailable: { ar: "لا توجد طلبات متاحة", en: "No orders available" },
  checkBackLater: { ar: "تحقق لاحقاً من الطلبات الجديدة", en: "Check back later for new orders" },
  
  // Orders List screen
  myOrders: { ar: "طلباتي", en: "My Orders" },
  orderId: { ar: "رقم الطلب", en: "Order ID" },
  status: { ar: "الحالة", en: "Status" },
  active: { ar: "نشط", en: "Active" },
  completed: { ar: "مكتمل", en: "Completed" },
  cancelled: { ar: "ملغي", en: "Cancelled" },
  noOrdersYet: { ar: "لا توجد طلبات بعد", en: "No orders yet" },
  startNewOrder: { ar: "ابدأ بإنشاء طلب جديد", en: "Start by creating a new order" },
  createNewOrder: { ar: "إنشاء طلب جديد", en: "Create New Order" },
  
  // Navigation
  back: { ar: "رجوع", en: "Back" },
  next: { ar: "التالي", en: "Next" },
  continue: { ar: "متابعة", en: "Continue" },
  
  // Common
  loading: { ar: "جاري التحميل...", en: "Loading..." },
  error: { ar: "حدث خطأ", en: "An error occurred" },
  success: { ar: "تم بنجاح", en: "Success" },
  
  // Profile screen
  editProfile: { ar: "تعديل الملف", en: "Edit Profile" },
  personalInfo: { ar: "المعلومات الشخصية", en: "Personal Information" },
  accountSecurity: { ar: "أمان الحساب", en: "Account Security" },
  managePassword: { ar: "إدارة كلمة المرور والأمان", en: "Manage password and security" },
  notificationSettings: { ar: "إعدادات الإشعارات", en: "Notification Settings" },
  manageNotifications: { ar: "إدارة الإشعارات والتنبيهات", en: "Manage notifications and alerts" },
  paymentMethods: { ar: "طرق الدفع", en: "Payment Methods" },
  managePayments: { ar: "إدارة طرق الدفع", en: "Manage payment methods" },
  helpSupport: { ar: "المساعدة والدعم", en: "Help & Support" },
  getHelp: { ar: "احصل على المساعدة", en: "Get help and support" },
  
  // Footer
  aboutUs: { ar: "من نحن", en: "About Us" },
  aboutUsDesc: { ar: "موترك هو منصة متخصصة في ربط أصحاب السيارات بموردي قطع الغيار باستخدام تقنيات الذكاء الاصطناعي لتحديد القطع المطلوبة بدقة.", en: "Motark is a platform specialized in connecting car owners with auto parts suppliers using AI technology to accurately identify required parts." },
  quickLinks: { ar: "روابط سريعة", en: "Quick Links" },
  contactUs: { ar: "تواصل معنا", en: "Contact Us" },
  privacyPolicy: { ar: "سياسة الخصوصية", en: "Privacy Policy" },
  termsOfService: { ar: "شروط الخدمة", en: "Terms of Service" },
  faq: { ar: "الأسئلة الشائعة", en: "FAQ" },
  allRightsReserved: { ar: "جميع الحقوق محفوظة", en: "All rights reserved" },
  followUs: { ar: "تابعنا", en: "Follow Us" },
  email: { ar: "البريد الإلكتروني", en: "Email" },
  phone: { ar: "الهاتف", en: "Phone" },
  address: { ar: "العنوان", en: "Address" },
  addressValue: { ar: "الرياض، المملكة العربية السعودية", en: "Riyadh, Saudi Arabia" },
}

interface LanguageContextType {
  language: Language
  setLanguage: (lang: Language) => void
  t: (key: string) => string
  dir: "ltr" | "rtl"
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined)

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguage] = useState<Language>("ar")

  const t = (key: string): string => {
    const translation = translations[key]
    if (!translation) return key
    return translation[language]
  }

  const dir = language === "ar" ? "rtl" : "ltr"

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t, dir }}>
      {children}
    </LanguageContext.Provider>
  )
}

export function useLanguage() {
  const context = useContext(LanguageContext)
  if (!context) {
    throw new Error("useLanguage must be used within a LanguageProvider")
  }
  return context
}
