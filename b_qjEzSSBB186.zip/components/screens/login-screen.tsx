"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { useAppStore } from "@/lib/store"
import { useLanguage } from "@/lib/i18n"
import { AppHeader } from "@/components/ui/app-header"
import { Phone, KeyRound, Mail, Building2, Send } from "lucide-react"

type LoginStep = "phone" | "otp"

export function LoginScreen() {
  const { t, dir, language } = useLanguage()
  const { phoneNumber, setPhoneNumber, otp, setOtp, login, setScreen } = useAppStore()
  const [error, setError] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [step, setStep] = useState<LoginStep>("phone")
  const [loginType, setLoginType] = useState<"customer" | "supplier">("customer")

  const handleSendOtp = async () => {
    setError("")
    
    if (!phoneNumber || phoneNumber.length < 9) {
      setError(language === "ar" ? "الرجاء إدخال رقم جوال صحيح" : "Please enter a valid phone number")
      return
    }
    
    setIsLoading(true)
    // Simulate sending OTP
    await new Promise((resolve) => setTimeout(resolve, 1000))
    setIsLoading(false)
    setStep("otp")
  }

  const handleVerifyOtp = async () => {
    setError("")
    
    if (otp !== "0000") {
      setError(t("invalidOtp"))
      return
    }
    
    setIsLoading(true)
    await new Promise((resolve) => setTimeout(resolve, 800))
    login(loginType)
    if (loginType === "supplier") {
      setScreen("orders-list")
    } else {
      setScreen("create-order")
    }
    setIsLoading(false)
  }

  const handleSupplierStart = () => {
    setLoginType("supplier")
    if (phoneNumber && phoneNumber.length >= 9) {
      handleSendOtp()
    }
  }

  const handleBackToPhone = () => {
    setStep("phone")
    setOtp("")
    setError("")
  }

  return (
    <div className="flex min-h-screen flex-col bg-background" dir={dir}>
      <AppHeader />
      
      <main className="flex flex-1 items-center justify-center p-4">
        <div className="w-full max-w-md space-y-8">
          {/* Logo Section */}
          <div className="text-center">
            <div className="mx-auto mb-4 flex h-20 w-20 items-center justify-center rounded-2xl bg-primary shadow-lg">
              <span className="text-4xl font-bold text-primary-foreground">M</span>
            </div>
            <h1 className="text-3xl font-bold text-foreground">{t("appName")}</h1>
            <p className="mt-2 text-muted-foreground">
              {language === "ar" ? "منصة قطع غيار السيارات الذكية" : "Smart Auto Parts Platform"}
            </p>
          </div>

          {/* Login Form */}
          <div className="rounded-2xl border border-border bg-card p-6 shadow-sm">
            <div className="space-y-5">
              {step === "phone" ? (
                <>
                  {/* Phone Number Step */}
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-foreground">
                      {t("phoneNumber")}
                    </label>
                    <div className="relative">
                      <Phone className="absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 text-muted-foreground" />
                      <Input
                        type="tel"
                        placeholder="+966 5x xxx xxxx"
                        value={phoneNumber}
                        onChange={(e) => {
                          setPhoneNumber(e.target.value)
                          setError("")
                        }}
                        className="h-12 pl-11 text-base"
                        dir="ltr"
                      />
                    </div>
                  </div>

                  {/* Error Message */}
                  {error && (
                    <div className="rounded-lg bg-destructive/10 p-3 text-center text-sm text-destructive">
                      {error}
                    </div>
                  )}

                  {/* Send OTP Button */}
                  <Button
                    onClick={() => {
                      setLoginType("customer")
                      handleSendOtp()
                    }}
                    disabled={isLoading}
                    className="h-12 w-full gap-2 text-base font-semibold"
                  >
                    {isLoading ? (
                      <span className="flex items-center gap-2">
                        <span className="h-4 w-4 animate-spin rounded-full border-2 border-primary-foreground border-t-transparent" />
                        {language === "ar" ? "جاري الإرسال..." : "Sending..."}
                      </span>
                    ) : (
                      <>
                        <Send className="h-5 w-5" />
                        {language === "ar" ? "إرسال رمز التحقق" : "Send OTP Code"}
                      </>
                    )}
                  </Button>

                  {/* Divider */}
                  <div className="relative">
                    <div className="absolute inset-0 flex items-center">
                      <div className="w-full border-t border-border" />
                    </div>
                    <div className="relative flex justify-center text-sm">
                      <span className="bg-card px-4 text-muted-foreground">{t("or")}</span>
                    </div>
                  </div>

                  {/* Alternative Login Options */}
                  <div className="space-y-3">
                    <Button
                      variant="outline"
                      className="h-12 w-full gap-2 text-base"
                    >
                      <Mail className="h-5 w-5" />
                      {t("loginByEmail")}
                    </Button>
                    
                    <Button
                      variant="secondary"
                      onClick={handleSupplierStart}
                      disabled={isLoading}
                      className="h-12 w-full gap-2 text-base"
                    >
                      <Building2 className="h-5 w-5" />
                      {t("registerAsWorkshop")}
                    </Button>
                  </div>
                </>
              ) : (
                <>
                  {/* OTP Verification Step */}
                  <div className="text-center">
                    <div className="mx-auto mb-3 flex h-14 w-14 items-center justify-center rounded-full bg-primary/10">
                      <KeyRound className="h-7 w-7 text-primary" />
                    </div>
                    <h2 className="text-xl font-bold text-foreground">
                      {language === "ar" ? "أدخل رمز التحقق" : "Enter Verification Code"}
                    </h2>
                    <p className="mt-2 text-sm text-muted-foreground">
                      {language === "ar" 
                        ? `تم إرسال رمز التحقق إلى ${phoneNumber}` 
                        : `We sent a verification code to ${phoneNumber}`}
                    </p>
                  </div>

                  {/* OTP Input */}
                  <div className="space-y-2">
                    <Input
                      type="text"
                      placeholder="0000"
                      value={otp}
                      onChange={(e) => {
                        const value = e.target.value.replace(/\D/g, "").slice(0, 4)
                        setOtp(value)
                        setError("")
                      }}
                      maxLength={4}
                      className="h-14 text-center text-2xl font-bold tracking-[0.5em]"
                      dir="ltr"
                      autoFocus
                    />
                  </div>

                  {/* Error Message */}
                  {error && (
                    <div className="rounded-lg bg-destructive/10 p-3 text-center text-sm text-destructive">
                      {error}
                    </div>
                  )}

                  {/* Verify Button */}
                  <Button
                    onClick={handleVerifyOtp}
                    disabled={isLoading || otp.length !== 4}
                    className="h-12 w-full text-base font-semibold"
                  >
                    {isLoading ? (
                      <span className="flex items-center gap-2">
                        <span className="h-4 w-4 animate-spin rounded-full border-2 border-primary-foreground border-t-transparent" />
                        {t("loading")}
                      </span>
                    ) : (
                      t("login")
                    )}
                  </Button>

                  {/* Resend & Back */}
                  <div className="flex items-center justify-between text-sm">
                    <button 
                      onClick={handleBackToPhone}
                      className="text-muted-foreground hover:text-foreground"
                    >
                      {language === "ar" ? "تغيير الرقم" : "Change number"}
                    </button>
                    <button className="text-primary hover:underline">
                      {t("resendCode")}
                    </button>
                  </div>
                </>
              )}
            </div>
          </div>

          {/* Demo hint */}
          <p className="text-center text-sm text-muted-foreground">
            {language === "ar" 
              ? "للتجربة: استخدم رمز التحقق 0000" 
              : "Demo: Use OTP code 0000"}
          </p>
        </div>
      </main>
    </div>
  )
}
