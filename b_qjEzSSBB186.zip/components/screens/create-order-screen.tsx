"use client"

import { useState, useRef } from "react"
import { Button } from "@/components/ui/button"
import { useAppStore } from "@/lib/store"
import { useLanguage } from "@/lib/i18n"
import { AppHeader } from "@/components/ui/app-header"
import { AppFooter } from "@/components/ui/app-footer"
import { Camera, Sparkles, Car, List } from "lucide-react"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"

const carModels = [
  { value: "Ford Taurus", label: "Ford Taurus", labelAr: "فورد تورس" },
  { value: "Toyota Camry", label: "Toyota Camry", labelAr: "تويوتا كامري" },
  { value: "Honda Accord", label: "Honda Accord", labelAr: "هوندا اكورد" },
  { value: "Nissan Altima", label: "Nissan Altima", labelAr: "نيسان التيما" },
  { value: "Hyundai Sonata", label: "Hyundai Sonata", labelAr: "هيونداي سوناتا" },
  { value: "Chevrolet Malibu", label: "Chevrolet Malibu", labelAr: "شيفروليه ماليبو" },
  { value: "Kia Optima", label: "Kia Optima", labelAr: "كيا اوبتيما" },
]

const years = ["2026", "2025", "2024", "2023", "2022", "2021", "2020", "2019", "2018"]

export function CreateOrderScreen() {
  const { t, dir, language } = useLanguage()
  const { setScreen, setCarDetails, setPhoto, currentOrder, orders } = useAppStore()
  const [selectedModel, setSelectedModel] = useState(currentOrder.carModel || "")
  const [selectedYear, setSelectedYear] = useState(currentOrder.carYear || "")
  const [uploadedImage, setUploadedImage] = useState<string | null>(currentOrder.photo)
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [error, setError] = useState("")
  const fileInputRef = useRef<HTMLInputElement>(null)

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onloadend = () => {
        setUploadedImage(reader.result as string)
        setPhoto(reader.result as string)
        setError("")
      }
      reader.readAsDataURL(file)
    }
  }

  const handleAnalyze = async () => {
    setError("")
    
    // Validation
    if (!selectedModel) {
      setError(language === "ar" ? "الرجاء اختيار موديل السيارة" : "Please select a car model")
      return
    }
    if (!selectedYear) {
      setError(language === "ar" ? "الرجاء اختيار سنة الصنع" : "Please select a year")
      return
    }
    if (!uploadedImage) {
      setError(language === "ar" ? "الرجاء رفع صورة للقطعة التالفة" : "Please upload a photo of the damaged part")
      return
    }

    setIsAnalyzing(true)
    setCarDetails(selectedModel, selectedYear)
    
    await new Promise((resolve) => setTimeout(resolve, 1500))
    setIsAnalyzing(false)
    setScreen("ai-result")
  }

  return (
    <div className="flex min-h-screen flex-col bg-background" dir={dir}>
      <AppHeader 
        showBack 
        onBack={() => setScreen("login")} 
      />
      
      <main className="flex flex-1 flex-col">
        <div className="container max-w-2xl flex-1 px-4 py-6">
          {/* Page Title */}
          <div className="mb-8 text-center">
            <h1 className="text-2xl font-bold text-foreground">
              {t("createOrder")} & {t("aiAnalysis")}
            </h1>
            <p className="mt-2 text-muted-foreground">
              {language === "ar" 
                ? "ارفع صورة للجزء التالف وسيقوم الذكاء الاصطناعي بتحديده" 
                : "Upload a photo of the damaged part and AI will identify it"}
            </p>
          </div>

          {/* My Orders Link */}
          {orders.length > 0 && (
            <button
              onClick={() => setScreen("orders-list")}
              className="mb-6 flex w-full items-center justify-between rounded-xl border border-border bg-card p-4 transition-colors hover:bg-secondary/50"
            >
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                  <List className="h-5 w-5 text-primary" />
                </div>
                <div className="text-left">
                  <p className="font-medium text-foreground">
                    {t("myOrders")}
                  </p>
                  <p className="text-sm text-muted-foreground">
                    {language === "ar" ? `${orders.length} طلبات` : `${orders.length} orders`}
                  </p>
                </div>
              </div>
              <span className="text-primary">→</span>
            </button>
          )}

          {/* Photo Upload Section */}
          <div className="mb-8">
            <label className="mb-3 block text-sm font-medium text-foreground">
              {t("photo")} *
            </label>
            <div 
              onClick={() => fileInputRef.current?.click()}
              className="group relative cursor-pointer overflow-hidden rounded-2xl border-2 border-dashed border-primary/30 bg-primary/5 transition-all hover:border-primary/50 hover:bg-primary/10"
            >
              {uploadedImage ? (
                <div className="relative aspect-video w-full">
                  <img 
                    src={uploadedImage} 
                    alt="Uploaded" 
                    className="h-full w-full object-cover"
                    crossOrigin="anonymous"
                  />
                  <div className="absolute inset-0 flex items-center justify-center bg-black/40 opacity-0 transition-opacity group-hover:opacity-100">
                    <Camera className="h-10 w-10 text-white" />
                  </div>
                </div>
              ) : (
                <div className="flex aspect-video flex-col items-center justify-center p-8">
                  <div className="mb-4 rounded-full bg-primary/10 p-4">
                    <Camera className="h-10 w-10 text-primary" />
                  </div>
                  <p className="text-center font-medium text-foreground">
                    {t("takePhoto")}
                  </p>
                  <p className="mt-1 text-center text-sm text-muted-foreground">
                    {t("withAI")}
                  </p>
                </div>
              )}
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handleImageUpload}
                className="hidden"
              />
            </div>
          </div>

          {/* Car Details Section */}
          <div className="mb-8 rounded-2xl border border-border bg-card p-6">
            <div className="mb-4 flex items-center gap-2">
              <Car className="h-5 w-5 text-primary" />
              <h2 className="text-lg font-semibold text-foreground">
                {t("carDetails")}
              </h2>
            </div>
            
            <div className="grid gap-4 sm:grid-cols-2">
              {/* Model Select */}
              <div className="space-y-2">
                <label className="text-sm font-medium text-foreground">
                  {t("model")} *
                </label>
                <Select value={selectedModel} onValueChange={(value) => {
                  setSelectedModel(value)
                  setError("")
                }}>
                  <SelectTrigger className="h-12">
                    <SelectValue placeholder={t("selectModel")} />
                  </SelectTrigger>
                  <SelectContent>
                    {carModels.map((model) => (
                      <SelectItem key={model.value} value={model.value}>
                        {language === "ar" ? model.labelAr : model.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Year Select */}
              <div className="space-y-2">
                <label className="text-sm font-medium text-foreground">
                  {t("year")} *
                </label>
                <Select value={selectedYear} onValueChange={(value) => {
                  setSelectedYear(value)
                  setError("")
                }}>
                  <SelectTrigger className="h-12">
                    <SelectValue placeholder={t("selectYear")} />
                  </SelectTrigger>
                  <SelectContent>
                    {years.map((year) => (
                      <SelectItem key={year} value={year}>
                        {year}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>

          {/* Error Message */}
          {error && (
            <div className="mb-4 rounded-lg bg-destructive/10 p-3 text-center text-sm text-destructive">
              {error}
            </div>
          )}

          {/* Action Button */}
          <Button
            onClick={handleAnalyze}
            disabled={isAnalyzing}
            className="h-14 w-full gap-2 text-base font-semibold"
            size="lg"
          >
            {isAnalyzing ? (
              <>
                <span className="h-5 w-5 animate-spin rounded-full border-2 border-primary-foreground border-t-transparent" />
                {language === "ar" ? "جاري التحليل..." : "Analyzing..."}
              </>
            ) : (
              <>
                <Sparkles className="h-5 w-5" />
                {language === "ar" ? "تحليل بالذكاء الاصطناعي" : "Analyze with AI"}
              </>
            )}
          </Button>
        </div>
      </main>

      <AppFooter />
    </div>
  )
}
