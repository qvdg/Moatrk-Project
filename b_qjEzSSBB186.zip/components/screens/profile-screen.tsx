"use client"

import { User, Phone, Mail, MapPin, Edit2, Camera, Shield, Bell, CreditCard, HelpCircle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { useLanguage } from "@/lib/i18n"
import { useAppStore } from "@/lib/store"
import { AppHeader } from "@/components/ui/app-header"
import { AppFooter } from "@/components/ui/app-footer"

export function ProfileScreen() {
  const { t, dir } = useLanguage()
  const { phoneNumber, userType, setScreen } = useAppStore()

  const profileSections = [
    {
      id: "account",
      icon: Shield,
      titleKey: "accountSecurity",
      descKey: "managePassword",
    },
    {
      id: "notifications",
      icon: Bell,
      titleKey: "notificationSettings",
      descKey: "manageNotifications",
    },
    {
      id: "payment",
      icon: CreditCard,
      titleKey: "paymentMethods",
      descKey: "managePayments",
    },
    {
      id: "help",
      icon: HelpCircle,
      titleKey: "helpSupport",
      descKey: "getHelp",
    },
  ]

  return (
    <div className="min-h-screen bg-background" dir={dir}>
      <AppHeader showMenu onBack={() => setScreen("orders-list")} />
      
      <main className="container mx-auto max-w-2xl px-4 py-8">
        {/* Profile Header */}
        <Card className="mb-6 overflow-hidden">
          <div className="h-24 bg-gradient-to-r from-primary to-primary/80" />
          <CardContent className="relative pb-6">
            <div className="absolute -top-12 left-1/2 -translate-x-1/2">
              <div className="relative">
                <div className="flex h-24 w-24 items-center justify-center rounded-full border-4 border-card bg-secondary">
                  <User className="h-12 w-12 text-muted-foreground" />
                </div>
                <button className="absolute bottom-0 right-0 flex h-8 w-8 items-center justify-center rounded-full bg-primary text-primary-foreground shadow-lg transition-transform hover:scale-110">
                  <Camera className="h-4 w-4" />
                </button>
              </div>
            </div>
            
            <div className="mt-14 text-center">
              <h2 className="text-xl font-bold text-foreground">
                {userType === "supplier" ? t("supplier") : t("customer")}
              </h2>
              <p className="mt-1 text-muted-foreground">{phoneNumber || "+966 5x xxx xxxx"}</p>
              
              <Button variant="outline" size="sm" className="mt-4 gap-2">
                <Edit2 className="h-4 w-4" />
                {t("editProfile")}
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Profile Info */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="text-lg">{t("personalInfo")}</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center gap-4 rounded-lg bg-secondary/50 p-4">
              <Phone className="h-5 w-5 text-primary" />
              <div>
                <p className="text-sm text-muted-foreground">{t("phoneNumber")}</p>
                <p className="font-medium text-foreground">{phoneNumber || "+966 5x xxx xxxx"}</p>
              </div>
            </div>
            
            <div className="flex items-center gap-4 rounded-lg bg-secondary/50 p-4">
              <Mail className="h-5 w-5 text-primary" />
              <div>
                <p className="text-sm text-muted-foreground">{t("email")}</p>
                <p className="font-medium text-foreground">user@example.com</p>
              </div>
            </div>
            
            <div className="flex items-center gap-4 rounded-lg bg-secondary/50 p-4">
              <MapPin className="h-5 w-5 text-primary" />
              <div>
                <p className="text-sm text-muted-foreground">{t("address")}</p>
                <p className="font-medium text-foreground">{t("addressValue")}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Settings Sections */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">{t("settings")}</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            {profileSections.map((section) => (
              <button
                key={section.id}
                className="flex w-full items-center gap-4 rounded-lg p-4 text-start transition-colors hover:bg-secondary"
              >
                <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10">
                  <section.icon className="h-5 w-5 text-primary" />
                </div>
                <div className="flex-1">
                  <p className="font-medium text-foreground">{t(section.titleKey)}</p>
                  <p className="text-sm text-muted-foreground">{t(section.descKey)}</p>
                </div>
              </button>
            ))}
          </CardContent>
        </Card>
      </main>

      <AppFooter />
    </div>
  )
}
