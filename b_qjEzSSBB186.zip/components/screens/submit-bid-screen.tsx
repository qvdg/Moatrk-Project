"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { useAppStore } from "@/lib/store"
import { useLanguage } from "@/lib/i18n"
import { AppHeader } from "@/components/ui/app-header"
import { AppFooter } from "@/components/ui/app-footer"
import { Send, ImageIcon, Package, CheckCircle2, Inbox } from "lucide-react"

export function SubmitBidScreen() {
  const { t, dir, language } = useLanguage()
  const { setScreen, orders, currentOrderId, submitBidForm, updateSubmitBidForm, submitSupplierBid, logout } = useAppStore()
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [submitted, setSubmitted] = useState(false)
  
  const currentOrder = orders.find(o => o.id === currentOrderId)
  
  // Filter only active orders for suppliers
  const activeOrders = orders.filter(o => o.status === "active")

  const handleSubmit = async () => {
    if (!submitBidForm.condition || !submitBidForm.price) return
    
    setIsSubmitting(true)
    await new Promise((resolve) => setTimeout(resolve, 1000))
    submitSupplierBid()
    setIsSubmitting(false)
    setSubmitted(true)
    
    setTimeout(() => {
      setSubmitted(false)
      setScreen("orders-list")
    }, 1500)
  }

  if (submitted) {
    return (
      <div className="flex min-h-screen flex-col bg-background" dir={dir}>
        <AppHeader />
        <main className="flex flex-1 items-center justify-center p-4">
          <div className="text-center">
            <div className="mx-auto mb-4 flex h-20 w-20 items-center justify-center rounded-full bg-accent">
              <CheckCircle2 className="h-10 w-10 text-accent-foreground" />
            </div>
            <h2 className="text-2xl font-bold text-foreground">
              {language === "ar" ? "تم إرسال العرض بنجاح!" : "Bid Submitted Successfully!"}
            </h2>
            <p className="mt-2 text-muted-foreground">
              {language === "ar" ? "جاري التوجيه..." : "Redirecting..."}
            </p>
          </div>
        </main>
      </div>
    )
  }

  // No order selected or no active orders
  if (!currentOrder || activeOrders.length === 0) {
    return (
      <div className="flex min-h-screen flex-col bg-background" dir={dir}>
        <AppHeader 
          showBack 
          onBack={logout}
        />
        <main className="flex flex-1 items-center justify-center p-4">
          <div className="text-center">
            <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-secondary">
              <Inbox className="h-8 w-8 text-muted-foreground" />
            </div>
            <h3 className="text-lg font-semibold text-foreground">
              {language === "ar" ? "لا توجد طلبات متاحة" : "No Orders Available"}
            </h3>
            <p className="mt-2 text-muted-foreground">
              {language === "ar" 
                ? "لا توجد طلبات متاحة للتقديم عليها حالياً" 
                : "There are no orders available to bid on at the moment."}
            </p>
            <Button onClick={logout} variant="outline" className="mt-6">
              {language === "ar" ? "تسجيل الخروج" : "Logout"}
            </Button>
          </div>
        </main>
        <AppFooter />
      </div>
    )
  }

  return (
    <div className="flex min-h-screen flex-col bg-background" dir={dir}>
      <AppHeader 
        showBack 
        showMenu
        onBack={logout} 
        onMenuClick={() => setScreen("orders-list")}
      />
      
      <main className="flex flex-1 flex-col">
        <div className="container max-w-2xl flex-1 px-4 py-6">
          {/* Order Info */}
          <div className="mb-6 rounded-2xl border border-border bg-card p-5">
            <div className="flex items-center gap-2 text-primary">
              <Package className="h-5 w-5" />
              <span className="font-medium">
                {language === "ar" ? "طلب رقم" : "Order"} #{currentOrder.id}
              </span>
            </div>
            <h1 className="mt-2 text-xl font-bold text-foreground">
              {currentOrder.carModel} {currentOrder.carYear}
            </h1>
          </div>

          {/* Order Parts */}
          <div className="mb-6">
            <h2 className="mb-3 text-lg font-semibold text-foreground">
              {t("orderParts")}
            </h2>
            
            {/* Photo */}
            <div className="mb-4 overflow-hidden rounded-2xl border border-border bg-primary/5">
              {currentOrder.photo ? (
                <img 
                  src={currentOrder.photo} 
                  alt="Order" 
                  className="aspect-video w-full object-cover"
                  crossOrigin="anonymous"
                />
              ) : (
                <div className="flex aspect-video items-center justify-center">
                  <div className="text-center">
                    <ImageIcon className="mx-auto h-12 w-12 text-primary/50" />
                    <p className="mt-2 text-sm text-muted-foreground">
                      {t("photo")}
                    </p>
                  </div>
                </div>
              )}
            </div>

            {/* Detected Parts */}
            {currentOrder.detectedParts.length > 0 && (
              <div className="rounded-xl bg-secondary/50 p-4">
                <p className="text-sm text-muted-foreground">{t("detected")}:</p>
                <p className="mt-1 font-medium text-foreground">
                  {currentOrder.detectedParts.join(", ")}
                </p>
              </div>
            )}
          </div>

          {/* Pricing Form */}
          <div className="mb-6 rounded-2xl border border-border bg-card p-6">
            <h2 className="mb-4 text-lg font-semibold text-foreground">
              {t("pricingFields")}
            </h2>
            
            <div className="space-y-4">
              {/* Condition */}
              <div className="space-y-2">
                <label className="text-sm font-medium text-foreground">
                  {t("condition")} *
                </label>
                <div className="flex gap-3">
                  {["new", "used"].map((condition) => (
                    <button
                      key={condition}
                      onClick={() => updateSubmitBidForm({ condition: condition as "new" | "used" })}
                      className={`flex-1 rounded-xl border-2 px-4 py-3 text-center font-medium transition-all ${
                        submitBidForm.condition === condition
                          ? "border-primary bg-primary text-primary-foreground"
                          : "border-border bg-card text-foreground hover:border-primary/50"
                      }`}
                    >
                      {condition === "new" ? t("new") : t("used")}
                    </button>
                  ))}
                </div>
              </div>

              {/* Warranty */}
              <div className="space-y-2">
                <label className="text-sm font-medium text-foreground">
                  {t("warranty")}
                </label>
                <Input
                  placeholder={language === "ar" ? "مثال: 6 أشهر" : "e.g., 6 months"}
                  value={submitBidForm.warranty}
                  onChange={(e) => updateSubmitBidForm({ warranty: e.target.value })}
                  className="h-12"
                />
              </div>

              {/* Price */}
              <div className="space-y-2">
                <label className="text-sm font-medium text-foreground">
                  {t("price")} ({t("sar")}) *
                </label>
                <Input
                  type="number"
                  placeholder="0"
                  value={submitBidForm.price}
                  onChange={(e) => updateSubmitBidForm({ price: e.target.value })}
                  className="h-12 text-lg"
                  dir="ltr"
                />
              </div>
            </div>
          </div>

          {/* Submit Button */}
          <Button
            onClick={handleSubmit}
            disabled={isSubmitting || !submitBidForm.condition || !submitBidForm.price}
            className="h-14 w-full gap-2 text-base font-semibold"
            size="lg"
          >
            {isSubmitting ? (
              <>
                <span className="h-5 w-5 animate-spin rounded-full border-2 border-primary-foreground border-t-transparent" />
                {t("loading")}
              </>
            ) : (
              <>
                <Send className="h-5 w-5" />
                {t("send")}
              </>
            )}
          </Button>
        </div>
      </main>

      <AppFooter />
    </div>
  )
}
