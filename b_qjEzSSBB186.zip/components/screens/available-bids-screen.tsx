"use client"

import { Button } from "@/components/ui/button"
import { useAppStore } from "@/lib/store"
import { useLanguage } from "@/lib/i18n"
import { AppHeader } from "@/components/ui/app-header"
import { AppFooter } from "@/components/ui/app-footer"
import { Check, X, Package, Clock, BadgeCheck, Hourglass } from "lucide-react"

export function AvailableBidsScreen() {
  const { t, dir, language } = useLanguage()
  const { setScreen, orders, currentOrderId, selectBid, rejectBid } = useAppStore()
  
  const currentOrder = orders.find(o => o.id === currentOrderId)

  const handleAccept = (bidId: string) => {
    if (currentOrder) {
      selectBid(currentOrder.id, bidId)
      setScreen("orders-list")
    }
  }

  const handleReject = (bidId: string) => {
    if (currentOrder) {
      rejectBid(currentOrder.id, bidId)
    }
  }

  // If no order found
  if (!currentOrder) {
    return (
      <div className="flex min-h-screen flex-col bg-background" dir={dir}>
        <AppHeader 
          showBack 
          onBack={() => setScreen("orders-list")} 
        />
        <main className="flex flex-1 items-center justify-center p-4">
          <div className="text-center">
            <Package className="mx-auto h-12 w-12 text-muted-foreground" />
            <h3 className="mt-4 text-lg font-medium text-foreground">
              {language === "ar" ? "لم يتم العثور على الطلب" : "Order not found"}
            </h3>
            <Button onClick={() => setScreen("orders-list")} className="mt-4">
              {language === "ar" ? "العودة للطلبات" : "Back to Orders"}
            </Button>
          </div>
        </main>
        <AppFooter />
      </div>
    )
  }

  return (
    <div className="flex min-h-screen flex-col bg-background" dir={dir}>
      <AppHeader 
        showBack 
        showMenu
        onBack={() => setScreen("orders-list")} 
        onMenuClick={() => setScreen("orders-list")}
      />
      
      <main className="flex flex-1 flex-col">
        <div className="container max-w-2xl flex-1 px-4 py-6">
          {/* Page Title */}
          <div className="mb-6">
            <h1 className="text-2xl font-bold text-foreground">
              {t("offersFor")} {currentOrder.carModel} {currentOrder.carYear}:
            </h1>
            <p className="mt-1 text-muted-foreground">
              {currentOrder.bids.length === 0 
                ? (language === "ar" ? "لا توجد عروض بعد" : "No offers yet")
                : (language === "ar" 
                    ? `${currentOrder.bids.length} عروض متاحة` 
                    : `${currentOrder.bids.length} offers available`)
              }
            </p>
          </div>

          {/* Bids List - Only show if there are bids */}
          {currentOrder.bids.length > 0 ? (
            <div className="space-y-4">
              {currentOrder.bids.map((bid) => (
                <div 
                  key={bid.id}
                  className="overflow-hidden rounded-2xl border border-border bg-card shadow-sm transition-shadow hover:shadow-md"
                >
                  <div className="p-5">
                    {/* Supplier Info */}
                    <div className="mb-4 flex items-start justify-between">
                      <div className="flex items-center gap-3">
                        <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
                          <Package className="h-6 w-6 text-primary" />
                        </div>
                        <div>
                          <h3 className="font-semibold text-foreground">
                            {language === "ar" ? bid.supplierNameAr : bid.supplierName}
                          </h3>
                          <p className="text-2xl font-bold text-primary">
                            {bid.price} {t("sar")}
                          </p>
                        </div>
                      </div>
                    </div>

                    {/* Bid Details */}
                    <div className="mb-4 flex flex-wrap gap-3">
                      <div className="flex items-center gap-2 rounded-full bg-secondary px-3 py-1.5">
                        <BadgeCheck className="h-4 w-4 text-secondary-foreground" />
                        <span className="text-sm font-medium text-secondary-foreground">
                          {t("condition")}: {bid.condition === "new" ? t("new") : t("used")}
                        </span>
                      </div>
                      <div className="flex items-center gap-2 rounded-full bg-secondary px-3 py-1.5">
                        <Clock className="h-4 w-4 text-secondary-foreground" />
                        <span className="text-sm font-medium text-secondary-foreground">
                          {t("warranty")}: {language === "ar" ? bid.warrantyAr : bid.warranty}
                        </span>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex gap-3">
                      <Button
                        onClick={() => handleAccept(bid.id)}
                        className="flex-1 gap-2"
                        size="lg"
                      >
                        <Check className="h-5 w-5" />
                        {language === "ar" ? "قبول" : "Accept"}
                      </Button>
                      <Button
                        onClick={() => handleReject(bid.id)}
                        variant="outline"
                        size="lg"
                        className="gap-2 border-destructive text-destructive hover:bg-destructive hover:text-destructive-foreground"
                      >
                        <X className="h-5 w-5" />
                        {language === "ar" ? "رفض" : "Reject"}
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            /* Empty State - Waiting for bids */
            <div className="rounded-2xl border border-dashed border-border bg-card p-12 text-center">
              <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-secondary">
                <Hourglass className="h-8 w-8 text-muted-foreground" />
              </div>
              <h3 className="text-lg font-semibold text-foreground">
                {language === "ar" ? "في انتظار عروض الموردين" : "Waiting for Supplier Offers"}
              </h3>
              <p className="mt-2 text-muted-foreground">
                {language === "ar" 
                  ? "تم إرسال طلبك للموردين، سيتم إعلامك عند وصول عروض جديدة" 
                  : "Your order has been sent to suppliers. You will be notified when offers arrive."}
              </p>
              <Button 
                variant="outline" 
                onClick={() => setScreen("orders-list")} 
                className="mt-6"
              >
                {language === "ar" ? "العودة لطلباتي" : "Back to My Orders"}
              </Button>
            </div>
          )}
        </div>
      </main>

      <AppFooter />
    </div>
  )
}
