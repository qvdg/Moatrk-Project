"use client"

import { Button } from "@/components/ui/button"
import { useAppStore } from "@/lib/store"
import { useLanguage } from "@/lib/i18n"
import { AppHeader } from "@/components/ui/app-header"
import { AppFooter } from "@/components/ui/app-footer"
import { Plus, Package, ChevronRight, LogOut, ShoppingBag } from "lucide-react"

export function OrdersListScreen() {
  const { t, dir, language } = useLanguage()
  const { setScreen, orders, setCurrentOrderId, logout, userType } = useAppStore()

  const handleOrderClick = (orderId: string) => {
    setCurrentOrderId(orderId)
    if (userType === "supplier") {
      setScreen("submit-bid")
    } else {
      setScreen("available-bids")
    }
  }

  const handleNewOrder = () => {
    setScreen("create-order")
  }

  const handleLogout = () => {
    logout()
  }

  const getStatusStyle = (status: string) => {
    switch (status) {
      case "active":
        return "bg-accent text-accent-foreground"
      case "completed":
        return "bg-primary text-primary-foreground"
      case "cancelled":
        return "bg-destructive text-destructive-foreground"
      default:
        return "bg-muted text-muted-foreground"
    }
  }

  const getStatusText = (status: string) => {
    switch (status) {
      case "active":
        return t("active")
      case "completed":
        return t("completed")
      case "cancelled":
        return t("cancelled")
      default:
        return status
    }
  }

  return (
    <div className="flex min-h-screen flex-col bg-background" dir={dir}>
      <AppHeader showMenu onMenuClick={handleLogout} />
      
      <main className="flex flex-1 flex-col">
        <div className="container max-w-2xl flex-1 px-4 py-6">
          {/* Header with action */}
          <div className="mb-6 flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-foreground">
                {t("myOrders")}
              </h1>
              <p className="mt-1 text-muted-foreground">
                {orders.length === 0 
                  ? (language === "ar" ? "لا توجد طلبات بعد" : "No orders yet")
                  : (language === "ar" ? `${orders.length} طلبات` : `${orders.length} orders`)
                }
              </p>
            </div>
            
            {userType === "customer" && (
              <Button onClick={handleNewOrder} className="gap-2">
                <Plus className="h-5 w-5" />
                {language === "ar" ? "طلب جديد" : "New Order"}
              </Button>
            )}
          </div>

          {/* Orders List - Only show if there are orders */}
          {orders.length > 0 ? (
            <div className="space-y-4">
              {orders.map((order) => (
                <button
                  key={order.id}
                  onClick={() => handleOrderClick(order.id)}
                  className="w-full overflow-hidden rounded-2xl border border-border bg-card p-5 text-left shadow-sm transition-all hover:border-primary/30 hover:shadow-md"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-secondary">
                        <Package className="h-6 w-6 text-secondary-foreground" />
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-medium text-muted-foreground">
                            {t("orderId")}:
                          </span>
                          <span className="font-bold text-foreground">
                            #{order.id}
                          </span>
                        </div>
                        <p className="mt-1 text-sm text-muted-foreground">
                          {order.carModel} {order.carYear}
                        </p>
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-3">
                      <span className={`rounded-full px-3 py-1.5 text-xs font-semibold ${getStatusStyle(order.status)}`}>
                        {getStatusText(order.status)}
                      </span>
                      <ChevronRight className="h-5 w-5 text-muted-foreground" />
                    </div>
                  </div>
                  
                  {/* Parts preview */}
                  {order.detectedParts.length > 0 && (
                    <div className="mt-3 flex flex-wrap gap-2">
                      {order.detectedParts.slice(0, 3).map((part, idx) => (
                        <span 
                          key={idx}
                          className="rounded-lg bg-muted px-2 py-1 text-xs text-muted-foreground"
                        >
                          {part}
                        </span>
                      ))}
                      {order.detectedParts.length > 3 && (
                        <span className="rounded-lg bg-muted px-2 py-1 text-xs text-muted-foreground">
                          +{order.detectedParts.length - 3}
                        </span>
                      )}
                    </div>
                  )}
                </button>
              ))}
            </div>
          ) : (
            /* Empty State */
            <div className="rounded-2xl border border-dashed border-border bg-card p-12 text-center">
              <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-secondary">
                <ShoppingBag className="h-8 w-8 text-muted-foreground" />
              </div>
              <h3 className="text-lg font-semibold text-foreground">
                {language === "ar" ? "لا توجد طلبات بعد" : "No orders yet"}
              </h3>
              <p className="mt-2 text-muted-foreground">
                {userType === "customer"
                  ? (language === "ar" 
                      ? "أنشئ طلبك الأول واحصل على عروض من الموردين" 
                      : "Create your first order and get offers from suppliers")
                  : (language === "ar"
                      ? "لا توجد طلبات متاحة حالياً للتقديم عليها"
                      : "No orders available to bid on at the moment")
                }
              </p>
              {userType === "customer" && (
                <Button onClick={handleNewOrder} className="mt-6 gap-2">
                  <Plus className="h-5 w-5" />
                  {language === "ar" ? "إنشاء طلب جديد" : "Create New Order"}
                </Button>
              )}
            </div>
          )}

          {/* Logout Button */}
          <div className="mt-8">
            <Button 
              variant="outline" 
              onClick={handleLogout}
              className="w-full gap-2"
            >
              <LogOut className="h-5 w-5" />
              {language === "ar" ? "تسجيل الخروج" : "Logout"}
            </Button>
          </div>
        </div>
      </main>

      <AppFooter />
    </div>
  )
}
