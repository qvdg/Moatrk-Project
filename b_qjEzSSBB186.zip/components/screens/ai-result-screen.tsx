"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { useAppStore } from "@/lib/store"
import { useLanguage } from "@/lib/i18n"
import { AppHeader } from "@/components/ui/app-header"
import { AppFooter } from "@/components/ui/app-footer"
import { Sparkles, Send, Edit3, CheckCircle2, ImageIcon } from "lucide-react"

export function AIResultScreen() {
  const { t, dir, language } = useLanguage()
  const { setScreen, currentOrder, submitOrder, setDetectedParts } = useAppStore()
  const [isSubmitting, setIsSubmitting] = useState(false)

  // Simulated AI detected parts
  const detectedParts = [
    { en: "Front Bumper", ar: "الصدام الأمامي" },
    { en: "Right Headlight", ar: "المصباح الأيمن" },
  ]

  const handleSubmit = async () => {
    setIsSubmitting(true)
    // Set detected parts before submitting
    setDetectedParts(detectedParts.map(p => p.en))
    await new Promise((resolve) => setTimeout(resolve, 1000))
    submitOrder()
    setIsSubmitting(false)
    setScreen("orders-list")
  }

  return (
    <div className="flex min-h-screen flex-col bg-background" dir={dir}>
      <AppHeader 
        showBack 
        onBack={() => setScreen("create-order")} 
      />
      
      <main className="flex flex-1 flex-col">
        <div className="container max-w-2xl flex-1 px-4 py-6">
          {/* Page Title */}
          <div className="mb-8 text-center">
            <h1 className="text-2xl font-bold text-foreground">
              {t("aiResult")} & {t("submitOrder")}
            </h1>
            <p className="mt-2 text-muted-foreground">
              {language === "ar" 
                ? `${currentOrder.carModel} ${currentOrder.carYear}` 
                : `${currentOrder.carModel} ${currentOrder.carYear}`}
            </p>
          </div>

          {/* Photo Preview */}
          <div className="mb-6">
            <label className="mb-3 block text-sm font-medium text-foreground">
              {t("photo")}
            </label>
            <div className="overflow-hidden rounded-2xl border border-border bg-primary/5">
              {currentOrder.photo ? (
                <img 
                  src={currentOrder.photo} 
                  alt="Car damage" 
                  className="aspect-video w-full object-cover"
                  crossOrigin="anonymous"
                />
              ) : (
                <div className="flex aspect-video items-center justify-center">
                  <div className="text-center">
                    <ImageIcon className="mx-auto h-16 w-16 text-primary/50" />
                    <p className="mt-2 text-muted-foreground">
                      {language === "ar" ? "صورة تجريبية" : "Demo Image"}
                    </p>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* AI Results Card */}
          <div className="mb-6 rounded-2xl border border-border bg-card p-6">
            <div className="mb-4 flex items-center gap-2">
              <div className="rounded-full bg-primary/10 p-2">
                <Sparkles className="h-5 w-5 text-primary" />
              </div>
              <h2 className="text-lg font-semibold text-foreground">
                {t("aiResult")}
              </h2>
            </div>

            {/* Detected Parts */}
            <div className="space-y-3">
              {detectedParts.map((part, index) => (
                <div 
                  key={index}
                  className="flex items-center gap-3 rounded-xl bg-accent/50 p-4"
                >
                  <CheckCircle2 className="h-5 w-5 shrink-0 text-accent-foreground" />
                  <div>
                    <p className="font-medium text-foreground">
                      {t("detected")}: {language === "ar" ? part.ar : part.en}
                    </p>
                  </div>
                </div>
              ))}
            </div>

            {/* Edit Link */}
            <button className="mt-4 flex items-center gap-2 text-sm text-primary hover:underline">
              <Edit3 className="h-4 w-4" />
              {t("editAddDetails")}
            </button>
          </div>

          {/* Submit Button */}
          <Button
            onClick={handleSubmit}
            disabled={isSubmitting}
            className="h-14 w-full gap-2 text-base font-semibold"
            size="lg"
          >
            {isSubmitting ? (
              <>
                <span className="h-5 w-5 animate-spin rounded-full border-2 border-primary-foreground border-t-transparent" />
                {t("loading")}
              </>
            ) : (
              <>
                <Send className="h-5 w-5" />
                {t("sendToSuppliers")}
              </>
            )}
          </Button>
        </div>
      </main>

      <AppFooter />
    </div>
  )
}
