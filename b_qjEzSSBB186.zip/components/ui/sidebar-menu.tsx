"use client"

import { X, Home, ShoppingBag, User, PlusCircle, LogOut } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useLanguage } from "@/lib/i18n"
import { useAppStore } from "@/lib/store"

interface SidebarMenuProps {
  isOpen: boolean
  onClose: () => void
}

export function SidebarMenu({ isOpen, onClose }: SidebarMenuProps) {
  const { t, dir } = useLanguage()
  const { setScreen, userType, logout, phoneNumber } = useAppStore()

  const handleNavigation = (screen: "create-order" | "orders-list" | "profile" | "submit-bid") => {
    setScreen(screen)
    onClose()
  }

  const handleLogout = () => {
    logout()
    onClose()
  }

  const customerMenuItems = [
    { id: "home", icon: Home, labelKey: "home", screen: "create-order" as const },
    { id: "new-order", icon: PlusCircle, labelKey: "newOrder", screen: "create-order" as const },
    { id: "my-orders", icon: ShoppingBag, labelKey: "myOrders", screen: "orders-list" as const },
    { id: "profile", icon: User, labelKey: "profile", screen: "profile" as const },
  ]

  const supplierMenuItems = [
    { id: "home", icon: Home, labelKey: "home", screen: "submit-bid" as const },
    { id: "available-orders", icon: ShoppingBag, labelKey: "availableOrders", screen: "submit-bid" as const },
    { id: "my-bids", icon: PlusCircle, labelKey: "myBids", screen: "orders-list" as const },
    { id: "profile", icon: User, labelKey: "profile", screen: "profile" as const },
  ]

  const menuItems = userType === "supplier" ? supplierMenuItems : customerMenuItems

  return (
    <>
      {/* Backdrop */}
      <div 
        className={`fixed inset-0 z-50 bg-black/50 transition-opacity duration-300 ${
          isOpen ? "opacity-100" : "opacity-0 pointer-events-none"
        }`}
        onClick={onClose}
      />
      
      {/* Sidebar */}
      <div 
        className={`fixed top-0 z-50 h-full w-80 max-w-[85vw] bg-card shadow-2xl transition-transform duration-300 ease-in-out ${
          dir === "rtl" ? "right-0" : "left-0"
        } ${
          isOpen 
            ? "translate-x-0" 
            : dir === "rtl" 
              ? "translate-x-full" 
              : "-translate-x-full"
        }`}
        dir={dir}
      >
        {/* Header */}
        <div className="flex items-center justify-between border-b border-border bg-primary p-4">
          <div className="flex items-center gap-3">
            <div className="flex h-12 w-12 items-center justify-center rounded-full bg-white">
              <span className="text-xl font-bold text-primary">M</span>
            </div>
            <div>
              <h2 className="text-lg font-bold text-primary-foreground">{t("appName")}</h2>
              <p className="text-sm text-primary-foreground/80">
                {phoneNumber || "+966 5x xxx xxxx"}
              </p>
            </div>
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={onClose}
            className="text-primary-foreground hover:bg-primary-foreground/10"
          >
            <X className="h-5 w-5" />
          </Button>
        </div>

        {/* User Type Badge */}
        <div className="border-b border-border p-4">
          <div className={`inline-flex items-center gap-2 rounded-full px-3 py-1 text-sm font-medium ${
            userType === "supplier" 
              ? "bg-accent/10 text-accent" 
              : "bg-primary/10 text-primary"
          }`}>
            <User className="h-4 w-4" />
            {userType === "supplier" ? t("supplier") : t("customer")}
          </div>
        </div>

        {/* Menu Items */}
        <nav className="flex-1 overflow-y-auto p-4">
          <ul className="space-y-1">
            {menuItems.map((item) => (
              <li key={item.id}>
                <button
                  onClick={() => handleNavigation(item.screen)}
                  className="flex w-full items-center gap-3 rounded-lg px-4 py-3 text-foreground transition-colors hover:bg-secondary"
                >
                  <item.icon className="h-5 w-5 text-muted-foreground" />
                  <span className="font-medium">{t(item.labelKey)}</span>
                </button>
              </li>
            ))}
          </ul>
        </nav>

        {/* Footer */}
        <div className="border-t border-border p-4">
          <button
            onClick={handleLogout}
            className="flex w-full items-center gap-3 rounded-lg px-4 py-3 text-destructive transition-colors hover:bg-destructive/10"
          >
            <LogOut className="h-5 w-5" />
            <span className="font-medium">{t("logout")}</span>
          </button>
          <p className="mt-4 text-center text-xs text-muted-foreground">
            {t("appName")} v1.0.0
          </p>
        </div>
      </div>
    </>
  )
}
