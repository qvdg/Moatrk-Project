"use client"

import { useLanguage } from "@/lib/i18n"
import { Phone, Mail, MapPin, Facebook, Twitter, Instagram, Linkedin } from "lucide-react"

export function AppFooter() {
  const { language } = useLanguage()
  const isArabic = language === "ar"

  return (
    <footer className="border-t border-border bg-card">
      <div className="container mx-auto max-w-6xl px-4 py-10">
        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-4">
          {/* About Section */}
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary">
                <span className="text-xl font-bold text-primary-foreground">M</span>
              </div>
              <span className="text-xl font-bold text-foreground">
                {isArabic ? "موترك" : "Motark"}
              </span>
            </div>
            <p className="text-sm leading-relaxed text-muted-foreground">
              {isArabic 
                ? "منصة موترك هي منصة سعودية رائدة في مجال قطع غيار السيارات، نستخدم الذكاء الاصطناعي لتحديد القطع التالفة وربطك بأفضل الموردين بأسعار تنافسية."
                : "Motark is a leading Saudi platform for auto parts. We use AI to identify damaged parts and connect you with the best suppliers at competitive prices."}
            </p>
          </div>

          {/* Quick Links */}
          <div className="space-y-4">
            <h3 className="font-semibold text-foreground">
              {isArabic ? "روابط سريعة" : "Quick Links"}
            </h3>
            <ul className="space-y-2 text-sm">
              <li>
                <a href="#" className="text-muted-foreground transition-colors hover:text-primary">
                  {isArabic ? "الرئيسية" : "Home"}
                </a>
              </li>
              <li>
                <a href="#" className="text-muted-foreground transition-colors hover:text-primary">
                  {isArabic ? "عن موترك" : "About Us"}
                </a>
              </li>
              <li>
                <a href="#" className="text-muted-foreground transition-colors hover:text-primary">
                  {isArabic ? "كيف يعمل" : "How it Works"}
                </a>
              </li>
              <li>
                <a href="#" className="text-muted-foreground transition-colors hover:text-primary">
                  {isArabic ? "انضم كمورد" : "Join as Supplier"}
                </a>
              </li>
              <li>
                <a href="#" className="text-muted-foreground transition-colors hover:text-primary">
                  {isArabic ? "الأسئلة الشائعة" : "FAQ"}
                </a>
              </li>
            </ul>
          </div>

          {/* Contact Info */}
          <div className="space-y-4">
            <h3 className="font-semibold text-foreground">
              {isArabic ? "تواصل معنا" : "Contact Us"}
            </h3>
            <ul className="space-y-3 text-sm">
              <li className="flex items-center gap-3 text-muted-foreground">
                <Phone className="h-4 w-4 text-primary" />
                <span dir="ltr">+966 50 000 0000</span>
              </li>
              <li className="flex items-center gap-3 text-muted-foreground">
                <Mail className="h-4 w-4 text-primary" />
                <span>support@motark.sa</span>
              </li>
              <li className="flex items-start gap-3 text-muted-foreground">
                <MapPin className="h-4 w-4 shrink-0 text-primary" />
                <span>
                  {isArabic 
                    ? "الرياض، المملكة العربية السعودية"
                    : "Riyadh, Saudi Arabia"}
                </span>
              </li>
            </ul>
          </div>

          {/* Social & Newsletter */}
          <div className="space-y-4">
            <h3 className="font-semibold text-foreground">
              {isArabic ? "تابعنا" : "Follow Us"}
            </h3>
            <div className="flex gap-3">
              <a 
                href="#" 
                className="flex h-10 w-10 items-center justify-center rounded-lg bg-secondary text-secondary-foreground transition-colors hover:bg-primary hover:text-primary-foreground"
              >
                <Twitter className="h-5 w-5" />
              </a>
              <a 
                href="#" 
                className="flex h-10 w-10 items-center justify-center rounded-lg bg-secondary text-secondary-foreground transition-colors hover:bg-primary hover:text-primary-foreground"
              >
                <Instagram className="h-5 w-5" />
              </a>
              <a 
                href="#" 
                className="flex h-10 w-10 items-center justify-center rounded-lg bg-secondary text-secondary-foreground transition-colors hover:bg-primary hover:text-primary-foreground"
              >
                <Facebook className="h-5 w-5" />
              </a>
              <a 
                href="#" 
                className="flex h-10 w-10 items-center justify-center rounded-lg bg-secondary text-secondary-foreground transition-colors hover:bg-primary hover:text-primary-foreground"
              >
                <Linkedin className="h-5 w-5" />
              </a>
            </div>
            <div className="space-y-2">
              <p className="text-sm text-muted-foreground">
                {isArabic 
                  ? "اشترك في النشرة البريدية"
                  : "Subscribe to our newsletter"}
              </p>
              <div className="flex gap-2">
                <input 
                  type="email" 
                  placeholder={isArabic ? "بريدك الإلكتروني" : "Your email"}
                  className="flex-1 rounded-lg border border-border bg-background px-3 py-2 text-sm outline-none focus:border-primary"
                />
                <button className="rounded-lg bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90">
                  {isArabic ? "اشترك" : "Subscribe"}
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="mt-10 border-t border-border pt-6">
          <div className="flex flex-col items-center justify-between gap-4 text-sm text-muted-foreground md:flex-row">
            <p>
              {isArabic 
                ? `© ${new Date().getFullYear()} موترك. جميع الحقوق محفوظة.`
                : `© ${new Date().getFullYear()} Motark. All rights reserved.`}
            </p>
            <div className="flex gap-6">
              <a href="#" className="hover:text-primary">
                {isArabic ? "سياسة الخصوصية" : "Privacy Policy"}
              </a>
              <a href="#" className="hover:text-primary">
                {isArabic ? "الشروط والأحكام" : "Terms & Conditions"}
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  )
}
