"use client"

import { LoginScreen } from "@/components/screens/login-screen"
import { CreateOrderScreen } from "@/components/screens/create-order-screen"
import { AIResultScreen } from "@/components/screens/ai-result-screen"
import { AvailableBidsScreen } from "@/components/screens/available-bids-screen"
import { SubmitBidScreen } from "@/components/screens/submit-bid-screen"
import { OrdersListScreen } from "@/components/screens/orders-list-screen"
import { ProfileScreen } from "@/components/screens/profile-screen"
import { useAppStore } from "@/lib/store"
import { LanguageProvider } from "@/lib/i18n"

function AppContent() {
  const { currentScreen } = useAppStore()

  const renderScreen = () => {
    switch (currentScreen) {
      case "login":
        return <LoginScreen />
      case "create-order":
        return <CreateOrderScreen />
      case "ai-result":
        return <AIResultScreen />
      case "available-bids":
        return <AvailableBidsScreen />
      case "submit-bid":
        return <SubmitBidScreen />
      case "orders-list":
        return <OrdersListScreen />
      case "profile":
        return <ProfileScreen />
      default:
        return <LoginScreen />
    }
  }

  return renderScreen()
}

export default function Home() {
  return (
    <LanguageProvider>
      <AppContent />
    </LanguageProvider>
  )
}
